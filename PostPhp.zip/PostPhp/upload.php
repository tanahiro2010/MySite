<?php
$zip = new ZipArchive;

function generateToken($length = 32) {
    // バイナリデータを生成
    $token = bin2hex(openssl_random_pseudo_bytes($length / 2));
    return $token;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
    // アップロードされたファイルの情報を取得
    $fileTmpPath = $_FILES['file']['tmp_name'];
    $fileName = generateToken();
    $fileSize = $_FILES['file']['size'];
    $fileType = $_FILES['file']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));

    // サーバー上で保存するファイルのパス
    $uploadFileDir = './zip/';
    $dest_path = $uploadFileDir . $fileName;

    // ディレクトリが存在しない場合は作成
    if (!is_dir($uploadFileDir)) {
        mkdir($uploadFileDir, 0777, true);
    }
    
    // ファイルをサーバーに移動
    if(move_uploaded_file($fileTmpPath, $dest_path)) {
        if ($zip->open($dest_path)){
            $zip->extractTo('./pages');
            $zip->close();
            echo "解凍完了<br>";
            echo "<h1>Link: https://tanahiro2010.cloudfree.jp/PostPhp/pages/$fileName";
        } else {
            echo "解凍に失敗しました";
        }
        echo "ファイルは正常にアップロードされました。<br>";

        // アップロードされたファイルの内容を読み取る
        $fileContent = file_get_contents($dest_path);
        echo "ファイル内容:<br>";
        echo nl2br(htmlspecialchars($fileContent));
    } else {
        echo "ファイルのアップロードに失敗しました。<br>";
    }
} else {
    echo "ファイルのアップロード中にエラーが発生しました。<br>";
}




?>