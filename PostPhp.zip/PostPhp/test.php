<?php
mkdir("./Test")
?>