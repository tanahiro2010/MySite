<?php
header("Location: ./app.html");
?>